﻿using DataAccessLayer;
using Entity;
using Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class VisitorBL
    {

        private static bool ValidateVisitor(Visitor visitor)
        {
            StringBuilder sb = new StringBuilder();
            bool validVisitor = true;
            if (visitor.GatePassID <= 0)
            {
                validVisitor = false;
                sb.Append(Environment.NewLine + "Invalid Visitor ID");

            }
            if (visitor.VisitorName == string.Empty)
            {
                validVisitor = false;
                sb.Append(Environment.NewLine + "Visitor Name Required");

            }

            if(!(System.Text.RegularExpressions.Regex.IsMatch(visitor.ContactNo.ToString(),"([8-9]{1}[0-9]{9})")))
            {
                validVisitor = false;
                sb.Append(Environment.NewLine + "Should start with 8 and 9");
            }




            if(!(System.Text.RegularExpressions.Regex.IsMatch(visitor.Email, @"^(?("")("".+?(?<!\\)""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
                @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-0-9a-z]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$")))
            {
                validVisitor = false;
                sb.Append(Environment.NewLine + "insert perfect email");
            }
            /*if (gateP.ContactNo.StartsWith("9") || gateP.ContactNo.StartsWith("8"))
            {
                validVisitor = true;
            }
            else
            {
                validVisitor = false;
                sb.Append(Environment.NewLine + "Contact Number should starts with 8 & 9");
            }*/



            if (Convert.ToString(visitor.ContactNo).Length != 10)
            {
                validVisitor = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }
            if (validVisitor == false)
                throw new VisitorException(sb.ToString());
            return validVisitor;
        }



        public static bool AddVisitorBL(Visitor newVisitor)
        {
            bool visitorAdded = false;
            try
            {
                if (ValidateVisitor(newVisitor))
                {
                    VisitorDAL visitorDAL = new VisitorDAL();
                    visitorAdded = visitorDAL.AddVisitorDAL(newVisitor);
                }
            }
            catch (VisitorException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return visitorAdded;
        }

        public static List<Visitor> GetAllVisitorBL()
        {
            List<Visitor> visitorList = null;
            try
            {
                VisitorDAL visitorDAL = new VisitorDAL();
                visitorList = visitorDAL.GetAllVisitorDAL();
            }
            catch (VisitorException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return visitorList;
        }


        public static Visitor SearchVisitorBL(int searchVisitorID)
        {
            Visitor searchVisitor = null;
            try
            {
                VisitorDAL visitorDAL = new VisitorDAL();
                searchVisitor = visitorDAL.SearchVisitorDAL(searchVisitorID);
            }
            catch (VisitorException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchVisitor;

        }










    }
}
