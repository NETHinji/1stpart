﻿using BusinessLayer;
using Entity;
using Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisitorPrac
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                int choice;
                do
                {
                    PrintMenu();
                    Console.WriteLine("Enter Your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddVisitor();
                            break;

                        case 2:
                            SearchVisitorByID();
                            break;

                        case 3:
                            ListAllVisitor();
                            break;
                        default:
                            Console.WriteLine("Invalid Choice...");
                            break;

                    }
                } while (choice != -1);

            }
            catch (SystemException sys)
            {

                throw new VisitorException(sys.Message);
            }

        }




        private static void AddVisitor()
        {
            try
            {
                VisitorBL visitorBL = new VisitorBL();
                Visitor newVisitor = new Visitor();
                Random r = new Random();
                newVisitor.GatePassID = r.Next(10000, 99999);
                Console.WriteLine("Enter Visitor Name:");
                newVisitor.VisitorName = Console.ReadLine();
                Console.WriteLine("Enter Date of Visit:");
                newVisitor.DateOfVisit = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter email");
                newVisitor.Email = Console.ReadLine();
                Console.WriteLine("Enter Contact Number:");
                newVisitor.ContactNo = long.Parse(Console.ReadLine());
                Console.WriteLine("Enter Purpose of Visit:");
                newVisitor.PurposeOfVisit = Console.ReadLine();
                Console.WriteLine("Enter Contact Person:");
                newVisitor.ContactPerson = Console.ReadLine();
                bool visitorAdded = VisitorBL.AddVisitorBL(newVisitor);
                if (visitorAdded)
                    Console.WriteLine("Visitor Added");
                else
                    Console.WriteLine("Visitor not Added");
            }
            catch (VisitorException ex)
            {
                Console.WriteLine(ex.Message);
            }

        
            catch (SystemException ex)
            {

                throw new VisitorException(ex.Message);
            }
        }



        private static void ListAllVisitor()
        {
            try
            {
                List<Visitor> visitorList = VisitorBL.GetAllVisitorBL();
                if (visitorList != null)
                {
                    Console.WriteLine("-------------------------------------------------------------------------------");
                    Console.WriteLine("GatePassID\t\tVisitorName\t\tDateOfVisit\t\tEmail\t\tContactNo\t\tPurposeOfVisit\t\tContactPerson");
                    Console.WriteLine("-------------------------------------------------------------------------------");
                    foreach (Visitor visitor in visitorList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}", visitor.GatePassID,visitor.VisitorName,visitor.DateOfVisit,visitor.Email,visitor.ContactNo,visitor.PurposeOfVisit,visitor.ContactPerson);
                    }
                    Console.WriteLine("-------------------------------------------------------------------------------");

                }
                else
                {
                    Console.WriteLine("No Visitor Details Available");
                }
            }
            catch (VisitorException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }




        private static void SearchVisitorByID()
        {
            try
            {
                int searchVisitorID;
                Console.WriteLine("Enter GatepassID to Search:");
                searchVisitorID = Convert.ToInt32(Console.ReadLine());
                Visitor searchVisitor = VisitorBL.SearchVisitorBL(searchVisitorID);
                if (searchVisitor != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("GatePassID\t\tVisitorName\t\tDateOfVisit\t\tEmail\t\tContactNo\t\tPurposeOfVisit\t\tContactPerson");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}", searchVisitor.GatePassID, searchVisitor.VisitorName, searchVisitor.DateOfVisit, searchVisitor.Email, searchVisitor.ContactNo, searchVisitor.PurposeOfVisit, searchVisitor.ContactPerson);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Visitor Details Available");
                }

            }
            catch (VisitorException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }





        public static void PrintMenu()
        {
            Console.WriteLine("1. Add Visitor");
            Console.WriteLine("2. Search Visitor");
            Console.WriteLine("3. Display Visitor's List");
        }









    }
}
