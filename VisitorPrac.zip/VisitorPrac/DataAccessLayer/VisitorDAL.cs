﻿using Entity;
using Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class VisitorDAL
    {

        public static List<Visitor> visitorList = new List<Visitor>();

        public bool AddVisitorDAL(Visitor newVisitor)
        {
            bool visitorAdded = false;
            try
            {
                visitorList.Add(newVisitor);
                visitorAdded = true;
            }
            catch (SystemException ex)
            {
                throw new VisitorException(ex.Message);
            }
            return visitorAdded;

        }

        public List<Visitor> GetAllVisitorDAL()
        {
            return visitorList;
        }



        public Visitor SearchVisitorDAL(int searchVisitorID)
        {
            Visitor searchVisitor = null;
            try
            {
                searchVisitor = visitorList.Find(visitor=>visitor.GatePassID == searchVisitorID);
            }
            catch (SystemException ex)
            {
                throw new VisitorException(ex.Message);
            }
            return searchVisitor;
        }



    }
}
