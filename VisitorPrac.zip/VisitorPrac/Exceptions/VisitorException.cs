﻿using System;
using System.Runtime.Serialization;

namespace Exceptions
{
    [Serializable]
    public class VisitorException : Exception
    {
        public VisitorException()
        {
        }

        public VisitorException(string message) : base(message)
        {
        }

        public VisitorException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected VisitorException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}