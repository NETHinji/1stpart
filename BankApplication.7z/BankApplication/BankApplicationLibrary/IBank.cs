﻿using System.ServiceModel;

namespace BankApplicationLibrary
{
    [ServiceContract]
   public interface IBank
    {
        [OperationContract]
        string Desposit();

        [OperationContract]
        string Withdraw();


    }
}