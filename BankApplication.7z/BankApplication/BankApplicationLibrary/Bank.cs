﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApplicationLibrary
{
    public class Bank : IBank
    {
        public string Desposit()
        {
            return "Deposited at " + DateTime.Now.ToString();
        }
        public string Withdraw()
        {
            return "Withdrawn at " + DateTime.Now.ToString();
        }
    }
}
