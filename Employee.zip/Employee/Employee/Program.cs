﻿using Employee.BL;
using Employee.Entity;
using Employee.Exception;
using System;
using System.Collections.Generic;

namespace Employee
{
    class Program
    {
       

        static void Main(string[] args)
        {

            EmployeeEntity employeeEntity = new EmployeeEntity();

            int ch = 0;
            do
            {
                ch = Convert.ToInt32(Console.ReadLine());
                try
                {
                    switch (ch)
                    {
                        case 1:

                            AddEmp(employeeEntity);
                             
                            
                            break;
                        case 2:
                            List<EmployeeEntity> employees = EmployeeBl.ShowBL(employeeEntity);
                            foreach(EmployeeEntity employee in employees)
                            {
                                Console.WriteLine(employeeEntity.EmpId+employeeEntity.EmpName+employeeEntity.Department+employeeEntity.ContactNumber);
                            }

                            break;
                    }
                }
                catch (EmployeeException)
                {
                    throw;
                }
            } while (ch != 0);
            
           
            
        }

        private static void  AddEmp(EmployeeEntity employeeEntity)
        {
            try
            {
                
                Random random = new Random();
                employeeEntity.EmpId =random.Next(1000, 9000).ToString();
                employeeEntity.EmpName = Console.ReadLine();
                employeeEntity.Department = Console.ReadLine();
                employeeEntity.Email = Console.ReadLine();
                employeeEntity.ContactNumber = Convert.ToInt64(Console.ReadLine());
                EmployeeBl employeeBl = new EmployeeBl();
                bool Added = employeeBl.AddBl(employeeEntity);
                if(Added)
                {
                    Console.WriteLine("Added Successfully");
                }
                else
                {
                    Console.WriteLine("Can't Added");
                }

            }
            catch(EmployeeException)
            {
                throw;
            }
        }
    }
}
