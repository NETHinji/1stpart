﻿using DataAccessLayer;
using Entity;
using Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class ServiceBL
    {

        public int AddService(Service sobj)
        {
            try
            {
                ServiceDAL pd = new ServiceDAL();
                return pd.AddService(sobj);
            }
            catch (ServiceException)
            {
                throw;
            }
        }


        public DataTable Display()
        {
            try
            {
                ServiceDAL pd = new ServiceDAL();
                return pd.Display();
            }
            catch (ServiceException)
            {
                throw;
            }
        }



    }
}
