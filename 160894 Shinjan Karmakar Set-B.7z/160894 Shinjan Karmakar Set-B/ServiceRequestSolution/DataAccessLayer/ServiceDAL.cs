﻿using Entity;
using Exceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class ServiceDAL
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;



        static ServiceDAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public ServiceDAL()
        {
            con = new SqlConnection(conStr);

        }
        public int AddService(Service sboj)
        {
            int sid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand();
                cmd.CommandText = "service1608.uspAddService";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;



                cmd.Parameters.AddWithValue("@sid", sboj.ServiceId);
                cmd.Parameters.AddWithValue("@dateofissue", sboj.Dateofissue);
                cmd.Parameters.AddWithValue("@ownername", sboj.OwnerName);
                cmd.Parameters.AddWithValue("@contactno", sboj.ContactNO);
                cmd.Parameters.AddWithValue("@devicetype", sboj.DeviceType);
                cmd.Parameters.AddWithValue("@serialno", sboj.SerialNo);
                cmd.Parameters.AddWithValue("@issuedescription", sboj.IssuDescription);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
               // sid = int.Parse(cmd.Parameters["@sId"].Value.ToString());
            }
            catch (ServiceException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return sid;
        }

        public DataTable Display()
        {
            DataTable dt = null;

            try
            {
                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "service1608.uspGetService";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (ServiceException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }



    }
}
