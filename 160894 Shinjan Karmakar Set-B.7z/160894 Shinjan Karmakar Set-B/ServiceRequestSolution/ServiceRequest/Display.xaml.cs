﻿using BusinessLayer;
using Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ServiceRequest
{
    /// <summary>
    /// Interaction logic for Display.xaml
    /// </summary>
    public partial class Display : Window
    {
        public Display()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                ServiceBL pb = new ServiceBL();
                DataTable dt = pb.Display();
                if (dt != null)
                {
                    dg1.ItemsSource = dt.DefaultView;
                }
                else
                {
                    MessageBox.Show("Table is empty", "Service Management System");
                }
            }
            catch (ServiceException ex)
            {
                MessageBox.Show(ex.Message, "Service Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Service Management System");
            }
        }
    }
}
