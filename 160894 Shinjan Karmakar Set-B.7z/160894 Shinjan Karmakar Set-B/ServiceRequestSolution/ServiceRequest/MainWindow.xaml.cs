﻿using BusinessLayer;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ServiceRequest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Service p = new Service();
            {
                p.ServiceId = txtserviceid.Text;
                p.Dateofissue =DateTime.Parse( txtdate.Text);
                p.OwnerName = txtowner.Text;
                p.ContactNO =long.Parse( txtcontact.Text);
                p.DeviceType = cmbtype.SelectedValue.ToString();
                p.SerialNo =int.Parse( txtserialno.Text);
                p.IssuDescription = txtdescription.Text;


                
            };
            ServiceBL sb = new ServiceBL();
            sb.AddService(p);
            //int sid = sb.AddService(p);
            //MessageBox.Show(string.Format("New serviceID Added.\n Service Id: {0}", sid),
            // "Service Management System");

            MessageBox.Show("Service request addes succesfully");
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
            cmbtype.ItemsSource = Enum.GetValues(typeof(DeviceType));

        }

        private void cmbtype_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int value = ((int)cmbtype.SelectedValue);
            MessageBox.Show(value.ToString());
        }
    }
    
}
