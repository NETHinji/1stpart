﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Service
    {
        public string ServiceId { get; set; }
        public DateTime Dateofissue { get; set; }
        public string OwnerName { get; set; }
        public long ContactNO { get; set; }
        public string DeviceType { get; set; }
        public int SerialNo { get; set; }
        public string IssuDescription { get; set; }
    }

    public enum DeviceType
    {
        Mobile = 1,
        Desktop = 2,
        Power_Bank = 3,
        
    }

}
