create schema service1608
go

create table service1608.service(
ServiceId varchar(50)  primary key,
Dateofissue Date,
OwnerName varchar(50) not null,
ContactNO bigint,
DeviceType varchar(50),
SerialNo int,
IssuDescription varchar(50)
)

create procedure service1608.uspAddService
(
@sid varchar(50),
@dateofissue date,
@ownername varchar(50),
@contactno bigint,
@devicetype varchar(50),
@serialno int,
@issuedescription varchar(50)


)
as
begin
	insert into service1608.service
	values(@sid,@dateofissue,@ownername,@contactno,@devicetype,@serialno,@issuedescription)
	
end



create proc service1608.uspGetService
as
begin
	select * from service1608.service
end


select * from service1608.service
